'''
Author: Marcus Adair, May 2024, University of Oregon

This file lies in a containerized version of MudPy. It is meant to run just the init and make_ruptures steps of Fakequakes for 
running on-demand Fakequakes. 
'''

from mudpy import fakequakes, parsecmdargs
from obspy.core import UTCDateTime


########                            GLOBALS                             ########
# SOME OF THE FOLLOWING PARAMETERS WILL BE CHANGED/CORRECTED by parsecmdargs and a user

home = '/PATH/TO/projects'		# get the absolute path of the current working directory which was passed in as as argument. set home
# Get the name of the job passed in. All the output data will be contained in a dir named after this unique job 
project_name = 'SET_THIS'
#  home+project_name = path to the output dir
run_name = 'run_v1'
 
################################################################################

##############             What do you want to do??           ##################
init=0
make_ruptures=0      

# Things that only need to be done once
load_distances=1
###############################################################################

#############                 Run-time parameters            ##################

# Initialize all of the default parameters

ncpus=4 # set to 1 when first running make_ruptures=1

model_name='vel1d_chile.mod'   # Velocity model
fault_name='chile.fault'    # Fault geometry
slab_name='chile.xyz'   # Slab 1.0 Ascii file (only used for 3D fault)
mesh_name='chile.mshout'    # GMSH output file (only used for 3D fault)
distances_name='planar_subduction' # Name of distance matrix
UTM_zone='19J'  # Look here if unsure (https://en.wikipedia.org/wiki/Universal_Transverse_Mercator_coordinate_system#/media/File:Utm-zones.jpg)
scaling_law='T' # Options: T for thrust, S for strike-slip, N for normal

#####################################################

#slip parameters
Nrealizations=4 # Number of fake ruptures to generate per magnitude bin. let Nrealizations % ncpus=0
target_Mw=8.5,9.2,0.2 # Of what approximate magnitudes. These default values will be pluggin into np.arange() by parsecmdargs if not specified via flag (-target_mw)
max_slip=100 #Maximum slip (m) allowed in the model

# Correlation function parameters
hurst=0.4  #0.4~0.7 is reasonable
Ldip='auto' # 'MH2019'      # Correlation length scaling, 'auto' uses  Mai & Beroza 2002, 
Lstrike='auto' # 'MH2019'   # MH2019 uses Melgar & Hayes 2019
lognormal='T'               # (True/False)
slip_standard_deviation=0.9
num_modes=100   #modes in K-L expantion (max#= munber of subfaults )
rake=90.0

# Rupture parameters
force_magnitude='F'    #Make the magnitudes EXACTLY the value in target_Mw
force_area='F'   #Forces using the entire fault area defined by the .fault file as opposed to the scaling laws (True/False)
no_random='F'   #If true uses median length/width if false draws from prob. distribution      (True/False)
time_epi=UTCDateTime('2016-09-07T14:42:26')  #Defines the hypocentral time
hypocenter=[0.8301,0.01,27.67]    #Defines the specific hypocenter location if force_hypocenter=True
force_hypocenter='F'     # Forces hypocenter to occur at specified lcoationa s opposed to random      (True/False)
mean_slip_name = None     #Provide path to file name of .rupt to be used as mean slip pattern

# center_subfault = None   #Integer value, if != None use that subfault as center for defining rupt area. If none then slected at random
shypo = None

use_hypo_fraction = 'F'  #If true use hypocenter PDF positions from Melgar & Hayes 2019, if false then selects at random      (True/False)

max_slip_rule='T' # not sure what does (marcus adair), added to be up to date                  (True/False)
slip_tol=1e-2

# Kinematic parameters
source_time_function='dreger' # options are 'triangle' or 'cosine' or 'dreger'
rise_time='MH2017'
rise_time_depths=[10,15] #Transition depths for rise time scaling
shear_wave_fraction_deep=0.8 # value of 0.8 from git def of generate_ruptures
shear_wave_fraction_shallow=0.49 # value of 0.49 from git def of generate_ruptures


###############################################################################
#----------------------- End of Parameters -----------------------------------#
###############################################################################





# Parse and set any passed in parameters passed in via file call
parsecmdargs.parse_cmdline_arguments(globals())

# For proper paths
home = home + '/'    

# Initalize project folders
if init==1:
    fakequakes.init(home,project_name) 



if make_ruptures==1:
    fakequakes.generate_ruptures(home,project_name,run_name,fault_name,slab_name,mesh_name,
        load_distances,distances_name,UTM_zone,target_Mw,model_name,hurst,Ldip,
        Lstrike,num_modes,Nrealizations,rake,rise_time,rise_time_depths,time_epi,
        max_slip,source_time_function,lognormal,slip_standard_deviation,scaling_law,ncpus,
        force_magnitude,force_area,mean_slip_name,hypocenter,
        slip_tol,force_hypocenter,no_random,shypo,use_hypo_fraction,
        shear_wave_fraction_shallow,shear_wave_fraction_deep,max_slip_rule)
