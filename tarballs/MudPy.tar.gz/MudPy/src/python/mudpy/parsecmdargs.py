'''
Marc Coll 05/2021

Add support for passing command line arguments. In order to use this feature you
just need to add the following two lines to your script:
    from mudpy import parsecmdargs
    parsecmdargs.parse_cmdline_arguments(globals())
They must be placed right after all the global configuration variables (ncpus,
model_name, fault_name, NFFT...) have been declared.


Edited: Marcus Adair 06/2022, 05/2024

Added changes necessary for additional parameters used by MudPy functions in 2022/2024
'''

import argparse
import sys
import re
import numpy as np
from obspy.core import UTCDateTime


def parse_cmdline_arguments(gobal_vars):
    if (len(sys.argv) <= 1):
        return

    '''
    Add here the names of the variables you want to be able to modify from the command line,
    and then modify the parse function accordingly
    '''
    params = [
        # FUNCTIONS:
        'init',
        'make_ruptures',
        'load_distances',

        # PARAMETERS:
        'ncpus',
        'model_name',
        'fault_name',
        'slab_name',
        'mesh_name',
        'distances_name',
        'UTM_zone',
        'scaling_law',
        'Nrealizations',
        'max_slip',
        'hurst',
        'Ldip',
        'Lstrike',
        'lognormal',
        'slip_standard_deviation',
        'num_modes',
        'rake',
        'force_magnitude',
        'force_area',
        'no_random',
        'time_epi',
        'hypocenter',
        'force_hypocenter',
        'mean_slip_name',
        'shypo',
        'use_hypo_fraction',
        'source_time_function',
        'rise_time',
        'rise_time_depths',
        'target_Mw',
        'max_slip_rule',
        'slip_tol',
        'shear_wave_fraction_deep',
        'shear_wave_fraction_shallow',
        'home',
        'project_name',
        'run_name'

    ]
    
    dict_params = {}
    for p in params:
        #Get values from existing variables using their names
        dict_params[p] = gobal_vars[p]
    ok,actions=parse(dict_params)
    if (ok == False):
        exit(1)
    if (len(actions) > 0):
        print("Actions: {}\nConfiguration:".format(actions))
    max_length = max(len(p) for p in params)
    for p in params:
        padding = ''.ljust(max_length - len(p) + 1)
        print("\t{}{}= {}".format(p, padding, dict_params[p]))
        #Set values to existing variables using their names
        gobal_vars[p] = dict_params[p]
    print("\n")


def parse(params):
    prog = sys.argv[0]
    description = "MudPy's command line arguments"
    epilog = '''Examples:
    {} init
    {} make_ruptures -load_distances=T
    '''.format(prog, prog, prog, prog)

    bool_choices=['T', 'F', 't', 'f', '0', '1']

    # Parse command line parameters
    parser = argparse.ArgumentParser(description=description, epilog=epilog,
                                     formatter_class=argparse.RawTextHelpFormatter)

    # What do you want to do?
    parser.add_argument('actions', nargs='*',
                        
                        metavar='[{init,make_ruptures}]',
                        choices=['init', 'make_ruptures'],
                        help='What do you want to do?\n'
                             ' * init: initialize project folders\n'
                             ' * make_ruptures: generate rupture models\n')

    parser.add_argument('-load_distances', default=str(params['load_distances']), metavar='[TF]',
                        choices=bool_choices,
                        help='load the distances instead of calculating them')
    # Run-time parameters
    parser.add_argument('-ncpus', type=int, default=params['ncpus'], metavar='N',
                        help='number of CPUs to use')
    parser.add_argument('-model_name', default=params['model_name'], metavar='NAME',
                        help='velocity model')
    parser.add_argument('-fault_name', default=params['fault_name'], metavar='NAME',
                        help='fault geometry')
    parser.add_argument('-slab_name', default=params['slab_name'], metavar='NAME',
                        help='slab 1.0 Ascii file (only used for 3D fault)')
    parser.add_argument('-mesh_name', default=params['mesh_name'], metavar='NAME',
                        help='GMSH output file (only used for 3D fault)')
    parser.add_argument('-distances_name', default=params['distances_name'], metavar='NAME',
                        help='name of distance matrix')
    parser.add_argument('-utm_zone', default=params['UTM_zone'], metavar='ZONE',
                        help='as defined in the Universal Transverse Mercator coordinate system')
    parser.add_argument('-scaling_law', default=params['scaling_law'], metavar='[TSN]',
                        #choices=['T', 'S', 'N'],
                        help='T for thrust, S for strike-slip, N for normal')
    # Slip parameters
    parser.add_argument('-nrealizations', type=int, default=params['Nrealizations'], metavar='N',
                        help='fake ruptures to generate per magnitude bin. Let Nrealizations %% ncpus=0')
    parser.add_argument('-max_slip', type=float, default=params['max_slip'], metavar='N',
                        help='maximum slip (m) allowed in the model')

    # Correlation function parameters
    parser.add_argument('-hurst', type=float, default=params['hurst'], metavar='N',
                        help='0.4~0.7 is reasonable')
    

    parser.add_argument('-ldip', default=params['Ldip'],
                        metavar='STRING,N',
                        help='Correlation length scaling')
    
    parser.add_argument('-lstrike', default=params['Lstrike'],
                        metavar='STRING,N',
                        help='Lstrike value (correlation function parameter)')
    



    parser.add_argument('-lognormal', default=str(params['lognormal']), metavar='[TF]',
                        choices=bool_choices,
                        help='')
    parser.add_argument('-slip_standard_deviation', type=float, default=params['slip_standard_deviation'], metavar='N',
                        help='')
    parser.add_argument('-num_modes', type=int, default=params['num_modes'], metavar='N',
                        help='modes in K-L expantion (max#= number of subfaults)')
    parser.add_argument('-rake', type=float, default=params['rake'], metavar='N',
                        help='')
    # Rupture parameters
    parser.add_argument('-force_magnitude', default=str(params['force_magnitude']), metavar='[TF]',
                        choices=bool_choices,
                        help='make the magnitudes EXACTLY the value in target_Mw')
    parser.add_argument('-force_area', default=str(params['force_area']), metavar='[TF]',
                        choices=bool_choices,
                        help='forces using the entire fault area defined by the .fault file')
    parser.add_argument('-no_random', default=str(params['no_random']), metavar='[TF]',
                        choices=bool_choices,
                        help='if true uses median length/width if false draws from prob. distribution')
    parser.add_argument('-time_epi', default=params['time_epi'].isoformat(), metavar='TIME',
                        help='defines the hypocentral time')
    # For None    
    parser.add_argument('-hypocenter', default=params['hypocenter'], metavar='N,N,N or None',
                        help='defines the specific hypocenter location if force_hypocenter=True')
    parser.add_argument('-force_hypocenter', default=str(params['force_hypocenter']), metavar='[TF]',
                        choices=bool_choices,
                        help='forces hypocenter to occur at specified location as opposed to random')
 
    parser.add_argument('-mean_slip_name', default=params['mean_slip_name'], metavar='NAME or None',
                        help='provide path to file name of .rupt to be used as mean slip pattern')

    parser.add_argument('-shypo', default=params['shypo'],
                        metavar='N or None',
                        help='')
    parser.add_argument('-use_hypo_fraction', default=str(params['use_hypo_fraction']), metavar='[TF]',
                        choices=bool_choices,
                        help='if true use hypocenter PDF positions from Melgar & Hayes 2019, if false then selects at random')
    # Kinematic parameters
    parser.add_argument('-source_time_function', default=params['source_time_function'],
                        choices=['triangle', 'cosine', 'dreger', 'ji'],
                        help='calculation method used in source time function')
    # TODO: Add choices?
    parser.add_argument('-rise_time', default=params['rise_time'],
                    help='rise time')

    parser.add_argument('-rise_time_depths', default=','.join(str(s) for s in params['rise_time_depths']), metavar='N,N',
                        help='transition depths for rise time scaling')
    

    # Arguments added by Marcus Adair in 2022

    parser.add_argument('-target_mw', default=','.join(str(s) for s in params['target_Mw']), metavar='N,N,N',
                        help='Parameters to be plugged into numpy.arange to specifiy of what approximate magnitudes')
    parser.add_argument('-max_slip_rule', default=str(params['max_slip_rule']), metavar='[TF]',
                        choices=bool_choices,
                        help='true or false')   
    
    parser.add_argument('-slip_tol', type=float, default=params['slip_tol'], metavar='N',
                        help='Slip tolerance')
    parser.add_argument('-shear_wave_fraction_deep', type=float, default=params['shear_wave_fraction_deep'], metavar='N',
                        help='Deep fraction of shear wave speed to use during calculation of rupture velocity')
    parser.add_argument('-shear_wave_fraction_shallow', type=float, default=params['shear_wave_fraction_shallow'], metavar='N',
                        help='Shallow fraction of shear wave speed to use during calculation of rupture velocity')

    parser.add_argument('-home', default=params['home'], metavar='PATH',
                        help='The directory where the folder structure created by init lies')
    parser.add_argument('-project_name', default=params['project_name'], metavar='NAME',
                        help='The name of the directory created in the init step')       
    parser.add_argument('-run_name', default=params['run_name'], metavar='NAME',
                        help='Name of the run. Can be be changed for labeling data when recycling parameters')         
    


    # Default initialization of actions
    params['init'] = 0
    params['make_ruptures'] = 0


    # Get parameter values
    args = parser.parse_args()
    if ('init' in args.actions):
        params['init'] = 1
    if ('make_ruptures' in args.actions):
        params['make_ruptures'] = 1
        
    params['load_distances'] = get_intbool(args.load_distances)

    # Simulation Configurations:
    # ------------------------------ #
    params['ncpus'] = args.ncpus
    params['model_name'] = args.model_name
    params['fault_name'] = args.fault_name
    params['slab_name'] = args.slab_name
    params['mesh_name'] = args.mesh_name
    params['distances_name'] = args.distances_name
    params['UTM_zone'] = args.utm_zone
    params['scaling_law'] = args.scaling_law
    params['Nrealizations'] = args.nrealizations
    params['max_slip'] = args.max_slip
    params['hurst'] = args.hurst
    params['Ldip'] = args.ldip
    params['Lstrike'] = args.lstrike
    params['lognormal'] = get_bool(args.lognormal)
    params['slip_standard_deviation'] = args.slip_standard_deviation
    params['num_modes'] = args.num_modes
    params['rake'] = args.rake
    params['force_magnitude'] = get_bool(args.force_magnitude)
    params['force_area'] = get_bool(args.force_area)
    params['no_random'] = get_bool(args.no_random)
    params['time_epi'] = UTCDateTime(args.time_epi)
    params['hypocenter'] = get_listOrNone(args.hypocenter, float)
    params['force_hypocenter'] = get_bool(args.force_hypocenter)
    params['mean_slip_name'] = args.mean_slip_name
    params['shypo'] = args.shypo
    params['use_hypo_fraction'] = get_bool(args.use_hypo_fraction)
    params['source_time_function'] = args.source_time_function
    params['rise_time'] = args.rise_time
    params['rise_time_depths'] = get_list(args.rise_time_depths, int)

    # Paramaters added by Marcus Adair in 2022
    params['target_Mw'] = get_list_call_arange(args.target_mw, float)
    params['max_slip_rule'] = get_bool(args.max_slip_rule)
    params['slip_tol'] = args.slip_tol  
    params['shear_wave_fraction_deep'] = args.shear_wave_fraction_deep
    params['shear_wave_fraction_shallow'] = args.shear_wave_fraction_shallow
    params['home'] = args.home
    params['project_name'] = args.project_name
    params['run_name'] = args.run_name


    # Check if some of the parameters make sense
    if (args.ncpus < 1):
        print('Invalid number of CPUs')
        return False,None

    if (len(params['rise_time_depths']) != 2):
        print('Invalid number of rise time depths')
        return False,None

    regex_utmzone = re.compile('^(A|B|Y|Z|([1-5][0-9]|60|0[1-9])[C-X])$')
    if (not regex_utmzone.match(args.utm_zone)):
        print('Invalid UTM zone')
        return False,None

    return True,args.actions



# Helper Methods:
# ------------------------- #
# def get_list(value, dtype):
#     return list(map(dtype, list(value.split(','))))

# def get_listOrNone(value, dtype):
#     if (value == 'None' or value is None):
#         return value
#     else:
#         return list(map(dtype, list(value.split(','))))


def get_list(value, dtype):
    if isinstance(value, list):
        return list(map(dtype, value))
    elif isinstance(value, str):
        return list(map(dtype, value.split(',')))


def get_listOrNone(value, dtype):
    if (value == 'None' or value is None):
        return None
    elif isinstance(value, list):
        return list(map(dtype, value))
    elif isinstance(value, str):
        return list(map(dtype, value.split(',')))
    else:
        return None



def get_bool(value):
    v = str(value).upper()
    return (v == 'T' or value == '1')


def get_intbool(value):
    if get_bool(value):
        return 1
    else:
        return 0

def get_list_call_arange(value, dtype):
    param_list = get_list(value, dtype) # seperate the values into a list

    param0 = param_list[0]
    param1 = param_list[1]
    param2 = param_list[2]

    return np.arange(param0, param1, param2)
        
